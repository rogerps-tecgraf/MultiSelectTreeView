﻿namespace System.Windows.Controls
{
	public class SelectionSingle
	{
	}
}
